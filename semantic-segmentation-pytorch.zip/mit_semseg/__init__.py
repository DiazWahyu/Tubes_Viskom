"""
MIT CSAIL Semantic Segmentation
"""

__version__ = '1.0.0'
